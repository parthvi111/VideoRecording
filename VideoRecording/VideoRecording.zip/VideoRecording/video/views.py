from django.shortcuts import render , render_to_response
import json
from django.template import RequestContext

from django.http import HttpResponseRedirect
from .forms import NameForm,MovieForm
from .models import Namemodl,Moviemodl
from django.core.urlresolvers import reverse



# Create your views here.

def index(request):
	return render(request , 'index.html' ,{})

def add_customer(request , name , number):
	d= {}
	d['Customer_NAME'] = name
	d['Customer_NUMBER'] = number
	d['Rental_Movie'] = '---'
	with open("video/customer_details.json", "w") as outfile:
    		json.dump(d, outfile, indent=4)
    		return render(request , 'index.html' ,{})

def save_name(request):
    if request.method == 'POST':
        form = NameForm(request.POST,auto_id=True)
        if form.is_valid():    
        	Name = request.POST.get('Name','')
        	Number = request.POST.get('Number','')
        	customer_obj = Namemodl(Name = Name , Number = Number)
        	customer_obj.save()
		return render_to_response('customer_data.html',{'customer_data':Namemodl.objects.all()})	

    else:
        form = NameForm()
    	return render(request, 'name.html', {'form': form})


def add_movie(request):
    if request.method == 'POST':
        form = MovieForm(request.POST)
        if form.is_valid():   

        	Name = request.POST.get('Name','')
        	No_of_copies = request.POST.get('No_of_copies','')
        	Movie_obj = Moviemodl(Name = Name , No_of_copies = No_of_copies , checks = False)
        	Movie_obj.save()
		return render_to_response('Movie_data.html',{'Movie_data':Moviemodl.objects.all()})	

    else:
        form = MovieForm()
    	return render(request, 'movie.html', {'form': form})


def rent_movie(request):
	if request.method == 'POST':

		checks =request.POST.getlist('checks')
		Name = request.POST.get('Name','')
		Number = request.POST.get('Number','')
		for i in checks:
			customer_data = Namemodl(Name = Name , Number = Number, Rented_movie = i).save()	
			Moviemodl.objects.filter(Name = i).update(No_of_copies=F("No_of_copies") - 1)	


		return render_to_response('customer_data.html',{'customer_data':Namemodl.objects.all()})	
	else:
		return render(request,'Rent_Movie.html',{'Movie_data':Moviemodl.objects.all()})	



def return_movie(request):
	if request.method == 'POST':
		Number = request.POST.get('Number','')
		return render_to_response('return_Movie_list.html',{'Movie_data':Namemodl.objects.filter(Number = Number)},context_instance=RequestContext(request))	

	else:
		return render(request,'return_movie.html',{})	

def return1(request):
	if request.method =='POST':
		checks =request.POST.getlist('checks')
		for i in checks:
			mv = Namemodl.objects.values('Rented_movie').filter(id = i)
			Moviemodl.objects.filter(Name = mv).update(No_of_copies=F("No_of_copies") + 1)
			Namemodl.objects.filter(id = i).delete()
			return render_to_response('customer_data.html',{'customer_data':Namemodl.objects.all()},context_instance=RequestContext(request))	
	else:

		pass



def check_movie(request):

	if request.method =='POST':
		 search = request.POST.get('search','')	
		 return render_to_response('Check_movie.html',{'check_movie':Moviemodl.objects.filter( Name = search)})
	else:
		return render(request,'Check_movie.html',{'check_movie':Moviemodl.objects.all()})

def print_customer(request):
	return render(request , 'customer_data.html' ,{'customer_data':Namemodl.objects.all()})


def print_movie(request):
	return render(request , 'Movie_data.html' ,{'Movie_data':Moviemodl.objects.all()})


def remove_customer(request):
	if request.method =='POST':
		checks =request.POST.getlist('checks')
		Name = request.POST.get('Name','')
		Number = request.POST.get('Number','')
		for i in checks:
			Namemodl.objects.filter(id = i).delete()
		return render_to_response('customer.html',{'customer':Namemodl.objects.all()},context_instance=RequestContext(request))
	else:
		return render(request, 'customer.html',{'customer':Namemodl.objects.all()},context_instance=RequestContext(request))


