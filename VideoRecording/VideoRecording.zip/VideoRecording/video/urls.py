from django.conf.urls import url
from django.contrib import admin
from . import views



urlpatterns = [

	url(r'^$',views.index,),
	url(r'^rent_movie/$',views.rent_movie,),
	url(r'^check_movie/$',views.check_movie,),
	url(r'^print_customer/$',views.print_customer,),
	url(r'^print_movie/$',views.print_movie,),
	url(r'^save_name/$',views.save_name,),
	url(r'^return_movie/$',views.return_movie,),
	url(r'^return1/$',views.return1,),
	url(r'^remove_customer/$',views.remove_customer,),
	url(r'^add_movie/$',views.add_movie,),






	url(r'^add/(?P<name>[\w]+)/(?P<number>[\d]+)/$',views.add_customer),
]
