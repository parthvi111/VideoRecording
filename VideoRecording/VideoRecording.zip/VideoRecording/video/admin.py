from django.contrib import admin
from .models import Namemodl,Moviemodl

# Register your models here.
admin.site.register(Namemodl)
admin.site.register(Moviemodl)