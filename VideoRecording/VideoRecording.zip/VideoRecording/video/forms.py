from django import forms
from .models import Moviemodl


class NameForm(forms.Form):
    Name = forms.CharField(max_length=100)
    Number = forms.IntegerField()


class MovieForm(forms.Form):
	Name = forms.CharField(max_length=100)
	No_of_copies = forms.IntegerField()

	