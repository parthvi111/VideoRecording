from __future__ import unicode_literals

from django.db import models

# Create your models here.

class Namemodl(models.Model):
    Name = models.CharField(max_length=100)
    Number = models.IntegerField()
    Rented_movie = models.CharField(max_length=100)

class Moviemodl(models.Model):

   Name = models.CharField(max_length=100)
   No_of_copies = models.IntegerField()
   checks = models.BooleanField(False)


